#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#define pi 3.142

static GLfloat angle = 0;
static int submenu;
static int mainmenu;
static int value = -1;
static GLuint txt;
static GLuint txt2;

void init();
void drawString(float x, float y, float z, char *string);
void drawHead(float x, float y, float z, char *string);
void drawsubhead(float x, float y, float z, char *string);
void menu(int option);
void createMenu(void);
void keyboard(unsigned char key, int x, int y);
void timer(int);
void display();

void circle(float rad)
{
    glBegin(GL_POINTS);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(rad * cos(i), rad * sin(i));
    }
    glEnd();
}

void rotate()
{
    angle = angle + 1.0;
    if (angle > 360)
    {
        angle = angle - 360;
    }

    glClear(GL_COLOR_BUFFER_BIT);
    glutPostRedisplay();
}

void nuc1(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 0, 0);
    for (float i = 0; i < (2 * pi); i = i + 0.00001)
    {
        glVertex2f(rad * cos(i), rad * sin(i));
    }
    glEnd();
}

void nuc2(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(0, 0, 1);
    for (float i = 0; i < (2 * pi); i = i + 0.00001)
    {
        glVertex2f(rad * cos(i), rad * sin(i));
    }
    glEnd();
}

void eleright(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(rad + 20 * cos(i), 20 * sin(i));
    }
    glEnd();
}

void eleleft(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(-(rad + 20 * cos(i)), 20 * sin(i));
    }
    glEnd();
}

void eletop(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(20 * cos(i), rad + 20 * sin(i));
    }
    glEnd();
}

void eledown(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(20 * cos(i), -(rad + 20 * sin(i)));
    }
    glEnd();
}

void eletr(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(((rad - 175) + 20 * cos(i)), ((rad - 175) + 20 * sin(i)));
    }
    glEnd();
}

void eletl(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(-((rad - 175) + 20 * cos(i)), ((rad - 175) + 20 * sin(i)));
    }
    glEnd();
}

void eledl(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(-((rad - 175) + 20 * cos(i)), -((rad - 175) + 20 * sin(i)));
    }
    glEnd();
}

void eledr(float rad)
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);
    for (float i = 0; i < (2 * pi); i += 0.00001)
    {
        glVertex2i(((rad - 175) + 20 * cos(i)), -((rad - 175) + 20 * sin(i)));
    }
    glEnd();
}

GLuint LoadTexture( const char * filename )
{
  GLuint texture;
  int width, height;
  unsigned char * data;

  FILE * file;
  file = fopen( filename, "rb" );

  if ( file == NULL ) return 0;
  width = 400;
  height = 300;
  data = (unsigned char *)malloc( width * height * 3 );
  //int size = fseek(file,);
  fread( data, width * height * 3, 1, file );
  fclose( file );

  for(int i = 0; i < width * height ; ++i)
  {
    int index = i*3;
    unsigned char B,R;
    B = data[index];
    R = data[index+2];

    data[index] = R;
    data[index+2] = B;
  }

  glGenTextures( 1, &texture );
  glBindTexture( GL_TEXTURE_2D, texture );
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, 
                   GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, 
                   GL_NEAREST);
  gluBuild2DMipmaps( GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data );
  free( data );

  return texture;
}

void init()
{
    gluOrtho2D(-640, 640, -360, 360);

    txt = LoadTexture("licl.bmp");
    txt2 = LoadTexture("naf.bmp");
}

void drawString(float x, float y, float z, char *string)
{
    glColor3f(1, 1, 1);
    glRasterPos3f(x, y, z);

    for (char *c = string; *c != '\0'; c++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
    }
}

void drawHead(float x, float y, float z, char *string)
{
    glColor3f(1, 1, 1);
    glRasterPos3f(x, y, z);

    for (char *c = string; *c != '\0'; c++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }
}

void drawsubhead(float x, float y, float z, char *string)
{
    glColor3f(1, 1, 1);
    glRasterPos3f(x, y, z);

    for (char *c = string; *c != '\0'; c++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }
}

void menu(int option)
{
    if (option == 10)
    {
        if(value == 2)
        {
            value = 1;
            glutIdleFunc(NULL);
        }
        
        if (value == 4)
        {
            value = 3;
            glutIdleFunc(NULL);
        }
    }

    else if (option == 20)
    {
        if(value == 1)
        {
            value = 2;
       glutIdleFunc(rotate);
        }

        if (value == 3)
        {
            value = 4;
            glutIdleFunc(rotate);
        }
    }

    else if (option == 30)
    {
        value =- 1;
    }

    else if (option == 40)
    {
        exit(0);
    }

    else
    {
        value = option;
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glutPostRedisplay();
}

void createMenu(void)
{
    submenu = glutCreateMenu(menu);
    glutAddMenuEntry("Sodium Fluoride (NaF)", 1);
    glutAddMenuEntry("Lithium Chloride (LiCl)", 3);

    mainmenu = glutCreateMenu(menu);
    glutAddSubMenu("Choose a molecule", submenu);
    glutAddMenuEntry("Properties view", 10);
    glutAddMenuEntry("Simulation view", 20);
    glutAddMenuEntry("Return to the homescreen", 30);
    glutAddMenuEntry("Exit (Q)", 40);

    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void keyboard(unsigned char key, int x, int y)
{
    if (key == 13)
    {
        value = 0;
        glClear(GL_COLOR_BUFFER_BIT);
        glutAttachMenu(GLUT_RIGHT_BUTTON);
        glutPostRedisplay();
    }

    else if (key == 'q' || key == 'Q')
    {
        exit(0);
    }
}

void timer(int)
{
    glutPostRedisplay();
    glutTimerFunc(1000/30, timer, 0);
}

void display()
{
glClear(GL_COLOR_BUFFER_BIT);

    if (value == -1)
    {
        char msg[] = "Press ENTER to continue";
        drawHead(-100,0,0, msg);

        glutSwapBuffers();
        glutDetachMenu(GLUT_RIGHT_BUTTON);
    }

    if(value == 0)
    {
        char msg2[] = "Right click to select a molecule";
        drawHead(-100, 0, 0, msg2);
    }

    if (value == 1)
    {
        glPushMatrix();
        char msg3[] = "Properties view";
        char msg4[] = "Sodium Fluoride (NaF)";
        char desc[] = "Sodium fluoride is a colorless crystalline solid or white powder, or the solid dissolved in a liquid. It is soluble in water. It is noncombustible. It is corrosive to aluminum.";
        char desc_cont[] = "It is used as an insecticide. It is also used to fluorinate water supplies, as a wood preservative, in cleaning compounds, manufacture of glass, and for many other uses.";
        drawHead(-80, 330, 0, msg3);
        drawHead(-100, 310, 0, msg4);
                drawString(-400, 280, 0, desc);
        drawString(-400, 265, 0, desc_cont);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-400, -150, 0);
        glEnable(GL_TEXTURE_2D);
        glBindTexture (GL_TEXTURE_2D, txt);
        glBegin(GL_QUADS);
            glTexCoord2f(0.0, 0.0); glVertex3f(0.0, 0.0, 0.0);
            glTexCoord2f(0.0, 1.0); glVertex3f(0, 300, 0.0);
            glTexCoord2f(1.0, 1.0); glVertex3f(400, 300, 0.0);
            glTexCoord2f(1.0, 0.0); glVertex3f(400, 0, 0.0);
        glEnd();
        glFlush();
        glDisable(GL_TEXTURE_2D);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(200, 0, 0);
        char formula[] = "Formula: NaF";
        char name[] = "Name: Sodium Fluoride";
        char type[] = "Type: Salt";
        char elem_class[] = "Class: Fluoride";
        char colour[] = "Clolour: White";
        char appearance[] = "Appearance: Crystaline solid";
        char molar_mass[] = "Molar mass: 41.98817 g/mol";
        char melting_point[] = "Melting point: 993 oC";
        char boiling_point[] = "Boiling point: 1695 oC";
        char density[] = "Density: 2.56 g/cm^3";
        drawString(0, 0, 0, formula);
        drawString(0, -20, 0, name);
        drawString(0, -40, 0, type);
        drawString(0, -60, 0, elem_class);
        drawString(0, -80, 0, colour);
        drawString(0, -100, 0, appearance);
        drawString(0, -120, 0, molar_mass);
        drawString(0, -140, 0, melting_point);
        drawString(0, -160, 0, boiling_point);
        drawString(0, -180, 0, density);
        glPopMatrix();

        glutSwapBuffers();
    }

    if (value == 2)
    {
        glPushMatrix();
        char msg31[] = "Simulation view";
        char msg41[] = "Sodium Fluoride (NaF)";
        drawHead(-80, 330, 0, msg31);
        drawHead(-100, 310, 0, msg41);
        glPopMatrix();

        char na_label[] = "Na +";
        char f_label[]= "F -";

        glPushMatrix();
        glTranslatef(-250, 0, 0);
        nuc1(50);
        drawString(-10, 0, 0, na_label);
        circle(100);
        circle(200);
        glPushMatrix();
            glRotatef(angle, 0, 0, 1);
            glColor3f(0, 1, 0);
            eletop(100);
            eledown(100);
        
            eletop(200);
            eledown(200);
            eleleft(200);
            eleright(200);
            eletl(320);
            eletr(320);
            eledl(320);
            eledr(320);
        glPopMatrix();
        glPopMatrix();
        
        glPushMatrix();
        glTranslatef(250, 0, 0);
        nuc2(50);
        drawString(-10, 0, 0, f_label);
        circle(100);
        circle(200);
        glPushMatrix();
            glRotatef(angle, 0, 0, 1);
            eletop(100);
            eledown(100);
        
            eletop(200);
            eledown(200);
            eleleft(200);
            eleright(200);
            eletl(320);
            eletr(320);
            eledl(320);
            eledr(320);
        glPopMatrix();
        glPopMatrix();

        glutSwapBuffers();
    }

    if (value == 3)
    {
        glPushMatrix();
        char msg5[] = "Properties view";
        char msg6[] = "Lithium Chloride (LiCl)";
        char desc[] = "Lithium chloride is a metal chloride salt with a Li(+) counterion. It has a role as an antimanic drug and a geroprotector. It is an inorganic chloride and a lithium salt.";
        drawHead(-80, 330, 0, msg5);
        drawHead(-100, 310, 0, msg6);
        drawString(-400, 280, 0, desc);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-400, -150, 0);
        glEnable(GL_TEXTURE_2D);
        glBindTexture (GL_TEXTURE_2D, txt2);
        glBegin(GL_QUADS);
            glTexCoord2f(0.0, 0.0); glVertex3f(0.0, 0.0, 0.0);
            glTexCoord2f(0.0, 1.0); glVertex3f(0, 300, 0.0);
            glTexCoord2f(1.0, 1.0); glVertex3f(400, 300, 0.0);
            glTexCoord2f(1.0, 0.0); glVertex3f(400, 0, 0.0);
        glEnd();
        glFlush();
        glDisable(GL_TEXTURE_2D);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(200, 0, 0);
        char formula[] = "Formula: LiCl";
        char name[] = "Name: Lithium Chloride";
        char type[] = "Type: Salt";
        char elem_class[] = "Class: Chloride";
        char colour[] = "Clolour: White";
        char appearance[] = "Appearance: Crystaline solid";
        char molar_mass[] = "Molar mass: 42.394 g/mol";
        char melting_point[] = "Melting point: 605 oC";
        char boiling_point[] = "Boiling point: 1382 oC";
        char density[] = "Density: 2.07 g/cm^3";
        drawString(0, 0, 0, formula);
        drawString(0, -20, 0, name);
        drawString(0, -40, 0, type);
        drawString(0, -60, 0, elem_class);
        drawString(0, -80, 0, colour);
        drawString(0, -100, 0, appearance);
        drawString(0, -120, 0, molar_mass);
        drawString(0, -140, 0, melting_point);
        drawString(0, -160, 0, boiling_point);
        drawString(0, -180, 0, density);
        glPopMatrix();

        glutSwapBuffers();
    }

    if (value == 4)
    {
        glPushMatrix();
        char msg51[] = "Simulation view";
        char msg61[] = "Lithium Chloride (LiCl)";
        drawHead(-80, 330, 0, msg51);
        drawHead(-100, 310, 0, msg61);
        glPopMatrix();

        char li_label[] = "Li +";
        char cl_label[]= "Cl -";

        glPushMatrix();
        glTranslatef(-250, 0, 0);
        nuc1(50);
        drawString(-10, 0, 0, li_label);
        circle(100);
        glPushMatrix();
            glRotatef(angle, 0, 0, 1);
            eletop(100);
            eledown(100);
        glPopMatrix();
        glPopMatrix();
        
        glPushMatrix();
        glTranslatef(250, 0, 0);
        nuc2(50);
        drawString(-10, 0, 0, cl_label);
        circle(100);
        circle(200);
        circle(300);
        glPushMatrix();
            glRotatef(angle, 0, 0, 1);
            glColor3f(1, 0, 0);
            eletop(100);
            eledown(100);
        
            eletop(200);
            eledown(200);
            eleleft(200);
            eleright(200);
            eletl(320);
            eletr(320);
            eledl(320);
            eledr(320);
        
            eletop(300);
            eledown(300);
            eleleft(300);
            eleright(300);
            eletl(390);
            eletr(390);
            eledl(390);
            eledr(390);
        glPopMatrix();
        glPopMatrix();

        glutSwapBuffers();
    }

    glutSwapBuffers();
}

int main(int argc, char**argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

    glutInitWindowPosition(100, 100);
    glutInitWindowSize(1280, 720);

    glutCreateWindow("IONIC BONDING SIMULATOR");

    init();
    glutDisplayFunc(display);
    glutTimerFunc(0, timer, 0);
    glutKeyboardFunc(keyboard);

    createMenu();

    glutMainLoop();
    return 0;
}
